Second Week: Stemming in python

Learnt how use the NLTK toolkit to stem words and filter out punctuations,
stop words.
