WEEK 3

Worked on lemmatization. New dataset now only has lemmatized words.

Learnt that lemmatization is a better option than stemming (as lemmatized words eutralare grammatically correct)

Used Label Encoder as well. 
Negative- 0
Neutral- 1
Positive- 2
