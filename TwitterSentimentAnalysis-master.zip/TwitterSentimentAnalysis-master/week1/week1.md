In the first week, I learnt how to obtain datasets using the Twitter API

Using Tweepy in Python I created a CSV file for Donald Trump's 200 recent tweets

In the code, all the tokens/keys are left blank. You can fill them using your own
keys/tokens from the twitter develepors website.
