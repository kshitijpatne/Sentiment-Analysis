Week 4

Finished with Twitter Sentiment Analysis,
Maximum Accuracy (with 80:20 split): 82.99% -using Naive Bayes classification Algorithm

Final Project- TwitterSentimentAnalysis.py
Code for Training Model- training.py
